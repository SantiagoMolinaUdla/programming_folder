#ifndef TORNEO_H
#define TORNEO_H

#include "ingreso.h"

void ingresarResultados(Equipo equipos[MAX_EQUIPOS]);

#endif /* TORNEO_H */